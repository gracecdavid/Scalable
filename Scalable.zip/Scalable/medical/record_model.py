# record_model.py
from pydantic import BaseModel, Field
from datetime import datetime
from bson import ObjectId

class MedicalRecord(BaseModel):
    patient_id: str
    provider_id: str
    record_type: str  # e.g., "Prescription", "Lab Report", "Consultation"
    content: str      # Record details, could be JSON or plain text
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    class Config:
        # Allows MongoDB ObjectId to be handled as a string in API responses
        json_encoders = {
            ObjectId: str
        }
