from pymongo import MongoClient
from pymongo.server_api import ServerApi

# Connect to MongoDB
uri = "mongodb+srv://scalable:scalable@scalable.0vx4z.mongodb.net/?retryWrites=true&w=majority&appName=scalable"
client = MongoClient(uri, server_api=ServerApi('1'))

# Create or switch to the database
db = client["healthcare_db"]

collection = db["medical_records"]

# Insert data into the collection
record = {
    "patient_id": "P008",
    "provider_id": "PR008",
    "record_type": "Consultation",
    "content": "Routine checkup.",
    "created_at": "2024-11-16T16:46:10.642Z"
}
collection.insert_one(record)

# Query the document
for user in collection.find():
    print(user)
