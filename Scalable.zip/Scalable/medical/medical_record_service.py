# medical_record_service.py
from fastapi import FastAPI, HTTPException
from pymongo import MongoClient
from record_model import MedicalRecord
import grpc
import medical_records_pb2_grpc
import medical_records_pb2
from pymongo.server_api import ServerApi
from typing import Dict


app = FastAPI()

# Connect to MongoDB
uri = "mongodb+srv://scalable:scalable@scalable.0vx4z.mongodb.net/?retryWrites=true&w=majority&appName=scalable"
client = MongoClient(uri, server_api=ServerApi('1'))
db = client["healthcare_db"]
records_collection = db["medical_records"]

class MedicalRecordService(medical_records_pb2_grpc.MedicalRecordServiceServicer):
    def AddMedicalRecord(self, request, context):
        record = MedicalRecord(
            patient_id=request.patient_id,
            provider_id=request.provider_id,
            record_type=request.record_type,
            content=request.content,
            created_at=request.created_at
        )
        records_collection.insert_one(record.dict())
        return medical_records_pb2.AddRecordResponse(message="Record added successfully.")

    def GetMedicalRecord(self, request, context):
        record = records_collection.find_one({"_id": request.record_id})
        if not record:
            context.abort(grpc.StatusCode.NOT_FOUND, "Record not found")
        return medical_records_pb2.GetRecordResponse(
            patient_id=record["patient_id"],
            provider_id=record["provider_id"],
            record_type=record["record_type"],
            content=record["content"],
            created_at=record["created_at"]
        )
@app.get("/medical-records/")
def read_root():
    return records_collection
def serialize_record(record: Dict):
    record["_id"] = str(record["_id"])  # Convert ObjectId to string
    record["created_at"] = record["created_at"].isoformat()  # Convert datetime to ISO string
    return record

@app.get("/patient-records/{patient_id}")
async def get_patient_record(patient_id: str):
    record = records_collection.find_one({"patient_id": patient_id})
    if record:
        # Convert the non-serializable fields
        serialized_record = serialize_record(record)
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")
    print(serialized_record)
    return serialized_record

# Add FastAPI routes for simple HTTP interaction
@app.post("/medical-records/")
async def add_medical_record(record: MedicalRecord):
    if records_collection.insert_one(record.dict()).inserted_id:
        return {"message": "Record added successfully"}
    raise HTTPException(status_code=500, detail="Failed to add record")

@app.get("/medical-records/{record_id}")
async def get_medical_record(record_id: str):
    record = records_collection.find_one({"_id": record_id})
    if not record:
        raise HTTPException(status_code=404, detail="Record not found")
    return record
