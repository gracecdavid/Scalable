# kafka_consumer.py
from kafka import KafkaConsumer
import json
from pymongo import MongoClient
from datetime import datetime

# MongoDB connection
client = MongoClient("mongodb://localhost:27017/")
db = client["healthcare_db"]
records_collection = db["medical_records"]

# Initialize Kafka Consumer
consumer = KafkaConsumer(
    'appointment-events',
    bootstrap_servers=['localhost:9092'],
    auto_offset_reset='earliest',
    enable_auto_commit=True,
    group_id='medical-records-service-group',
    value_deserializer=lambda x: json.loads(x.decode('utf-8'))
)

print("Kafka consumer started, listening for appointment events...")

# Listen for messages in 'appointment-events' topic
for message in consumer:
    event = message.value
    print(f"Received event: {event}")

    # Process only if it's an 'AppointmentCreated' event
    if event["event"] == "AppointmentCreated":
        # Create a new medical record entry for the appointment
        record = {
            "patient_id": event["data"]["patient_id"],
            "provider_id": event["data"]["provider_id"],
            "record_type": "Appointment",
            "content": f"Appointment scheduled for {event['data']['appointment_date']}",
            "created_at": datetime.utcnow()
        }
        records_collection.insert_one(record)
        print("Medical record added for new appointment")
