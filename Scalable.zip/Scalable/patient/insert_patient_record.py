from fastapi import FastAPI, HTTPException
from pymongo import MongoClient
from patient_model import Patient  # Import the patient model
import grpc
import patient_records_pb2_grpc
import patient_records_pb2
from pymongo.server_api import ServerApi

app = FastAPI()

# MongoDB connection setup for patient_records collection
uri = "mongodb+srv://scalable:scalable@scalable.0vx4z.mongodb.net/?retryWrites=true&w=majority&appName=scalable"
client = MongoClient(uri, server_api=ServerApi('1'))
db = client["healthcare_db"]  # Use the healthcare_db
patient_collection = db["patient_records"]  # Use the patient_records collection

class PatientRecordService(patient_records_pb2_grpc.PatientRecordServiceServicer):
    def AddPatientRecord(self, request, context):
        # Create a new patient record from the incoming request
        patient_record = Patient(
            patient_id=request.patient_id,
            name=request.name,
            age=request.age,
            gender=request.gender,
            contact_info=request.contact_info,
            created_at=request.created_at
        )
        
        # Insert the patient record into MongoDB
        result = patient_collection.insert_one(patient_record.dict())
        
        # Check if record was inserted successfully
        if result.inserted_id:
            return patient_records_pb2.AddRecordResponse(message="Patient record added successfully.")
        else:
            context.abort(grpc.StatusCode.INTERNAL, "Failed to add patient record.")
    
    def GetPatientRecord(self, request, context):
        # Retrieve the patient record from MongoDB by patient_id
        record = patient_collection.find_one({"patient_id": request.patient_id})
        
        if not record:
            context.abort(grpc.StatusCode.NOT_FOUND, "Patient record not found.")
        
        return patient_records_pb2.GetRecordResponse(
            patient_id=record["patient_id"],
            name=record["name"],
            age=record["age"],
            gender=record["gender"],
            contact_info=record["contact_info"],
            created_at=record["created_at"]
        )

# Add FastAPI routes for HTTP interaction (for testing)
@app.post("/patient-records/")
async def add_patient_record(record: Patient):
    # Insert the record into MongoDB
    result = patient_collection.insert_one(record.dict())
    
    if result.inserted_id:
        return {"message": "Patient record added successfully"}
    else:
        raise HTTPException(status_code=500, detail="Failed to add patient record")

@app.get("/patient-records/{patient_id}")
async def get_patient_record(patient_id: str):
    # Retrieve the patient record by patient_id
    record = patient_collection.find_one({"patient_id": patient_id})
    
    if not record:
        raise HTTPException(status_code=404, detail="Patient record not found")
    
    return record
