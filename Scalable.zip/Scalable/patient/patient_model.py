from pydantic import BaseModel, Field
from datetime import datetime
from bson import ObjectId

class Patient(BaseModel):
    patient_id: str
    name: str
    age: int
    gender: str
    contact_info: str  # This could be a phone number or email address
    created_at: datetime = Field(default_factory=datetime.utcnow)

    class Config:
        # Allows MongoDB ObjectId to be handled as a string in API responses
        json_encoders = {
            ObjectId: str
        }
