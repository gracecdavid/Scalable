from fastapi import FastAPI, HTTPException
from pymongo import MongoClient
from patient_model import Patient  # Assuming Patient model is defined in patient_model.py
import grpc
import patient_records_pb2_grpc  # gRPC generated files for Patient Record service
import patient_records_pb2
from typing import Dict

app = FastAPI()

# MongoDB connection setup
uri = "mongodb+srv://scalable:scalable@scalable.0vx4z.mongodb.net/?retryWrites=true&w=majority&appName=scalable"
client = MongoClient(uri, server_api=ServerApi('1'))
db = client["healthcare_db"]
patients_collection = db["patients"]  # Assuming you want to store patients in a 'patients' collection

# gRPC Service Class
class PatientRecordService(patient_records_pb2_grpc.PatientRecordServiceServicer):
    def AddPatientRecord(self, request, context):
        # Assuming request has the same fields as the Patient model
        patient = Patient(
            patient_id=request.patient_id,
            name=request.name,
            age=request.age,
            gender=request.gender,
            contact_info=request.contact_info,
            created_at=request.created_at
        )
        
        # Insert the patient record into MongoDB
        patients_collection.insert_one(patient.dict())
        return patient_records_pb2.AddRecordResponse(message="Patient record added successfully.")

    def GetPatientRecord(self, request, context):
        patient = patients_collection.find_one({"patient_id": request.patient_id})
        
        if not patient:
            context.abort(grpc.StatusCode.NOT_FOUND, "Patient record not found")
        
        # Return patient details in gRPC response
        return patient_records_pb2.GetRecordResponse(
            patient_id=patient["patient_id"],
            name=patient["name"],
            age=patient["age"],
            gender=patient["gender"],
            contact_info=patient["contact_info"],
            created_at=patient["created_at"]
        )

# FastAPI routes for HTTP interaction with Patient Record service
@app.post("/patients/")
async def add_patient_record(patient: Patient):
    # Insert the patient record into MongoDB
    inserted_id = patients_collection.insert_one(patient.dict()).inserted_id
    
    if inserted_id:
        return {"message": "Patient record added successfully"}
    
    raise HTTPException(status_code=500, detail="Failed to add patient record")

@app.get("/patients/{patient_id}")
async def get_patient_record(patient_id: str):
    # Find patient record by patient_id
    patient = patients_collection.find_one({"patient_id": patient_id})
    
    if not patient:
        raise HTTPException(status_code=404, detail="Patient record not found")
    
    return patient

